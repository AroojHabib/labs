#include <iostream>
#include "CustomList.h"

using namespace std;

int main() {
    CustomList<int> list(10);
    int choice, val;

    do {
        cout << "\n1 Add End\n2 Add Start\n3 Remove End\n4 Sum of Primes\n5 Duplicates\n0 Exit\n";
        cin >> choice;

        switch (choice) {
        case 1:
            cin >> val;
            list.addElementAtLastIndex(val);
            break;
        case 2:
            cin >> val;
            list.addElementAtFirstIndex(val);
            break;
        case 3:
            cout << list.removeElementFromEnd() << endl;
            break;
        case 4:
            cout << list.sum_ofPrime() << endl;
            break;
        case 5:
            list.printDuplicates();
            break;
        }
    } while (choice != 0);

    return 0;
}