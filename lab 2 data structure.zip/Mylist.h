#pragma once
#include "List.h"

template <class T>
class MyList : public List<T> {
public:
    MyList(int m = 10) : List<T>(m) {}

    bool empty() {
        return this->currentSize == 0;
    }

    bool full() {
        return this->currentSize == this->maxSize;
    }

    int size() {
        return this->currentSize;
    }

    void addElementAtFirstIndex(T value) {
        if (full()) return;
        for (int i = this->currentSize; i > 0; i--)
            this->arr[i] = this->arr[i - 1];
        this->arr[0] = value;
        this->currentSize++;
    }

    void addElementAtLastIndex(T value) {
        if (full()) return;
        this->arr[this->currentSize++] = value;
    }

    T removeElementFromEnd() {
        if (empty()) return T();
        return this->arr[--this->currentSize];
    }

    void removeElementFromStart() {
        if (empty()) return;
        for (int i = 0; i < this->currentSize - 1; i++)
            this->arr[i] = this->arr[i + 1];
        this->currentSize--;
    }

    bool insertAt(int index, T value) {
        if (index < 0 || index > this->currentSize || full())
            return false;

        for (int i = this->currentSize; i > index; i--)
            this->arr[i] = this->arr[i - 1];

        this->arr[index] = value;
        this->currentSize++;
        return true;
    }

    T last() {
        return this->arr[this->currentSize - 1];
    }

    bool search(T value) {
        for (int i = 0; i < this->currentSize; i++)
            if (this->arr[i] == value)
                return true;
        return false;
    }
};

