#pragma once
template <class T>
class List {
protected:
    T* arr;
    int maxSize;
    int currentSize;

public:
    List(int m = 10) {
        maxSize = m;
        currentSize = 0;
        arr = new T[maxSize];
    }

    List(const List& other) {
        maxSize = other.maxSize;
        currentSize = other.currentSize;
        arr = new T[maxSize];
        for (int i = 0; i < currentSize; i++)
            arr[i] = other.arr[i];
    }

    virtual ~List() {
        delete[] arr;
    }

    virtual void addElementAtFirstIndex(T) = 0;
    virtual void addElementAtLastIndex(T) = 0;
    virtual T removeElementFromEnd() = 0;
    virtual void removeElementFromStart() = 0;
};

