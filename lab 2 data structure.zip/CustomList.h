#pragma once
#include "MyList.h"
#include <iostream>
using namespace std;

bool isPrime(int n) {
    if (n <= 1) return false;
    for (int i = 2; i < n; i++)
        if (n % i == 0) return false;
    return true;
}

template <class T>
class CustomList : public MyList<T> {
public:
    CustomList(int m = 10) : MyList<T>(m) {}

    T sum_ofPrime() {
        T sum = 0;
        for (int i = 0; i < this->currentSize; i++)
            if (isPrime(this->arr[i]))
                sum += this->arr[i];
        return sum;
    }

    void printDuplicates() {
        for (int i = 0; i < this->currentSize; i++)
            for (int j = i + 1; j < this->currentSize; j++)
                if (this->arr[i] == this->arr[j]) {
                    cout << this->arr[i] << " ";
                    break;
                }
        cout << endl;
    }
};

