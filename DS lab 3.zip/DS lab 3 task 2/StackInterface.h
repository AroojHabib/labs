
template <class DataType>
class StackInterface {

public:
    virtual void push(DataType item) = 0;
    virtual DataType pop() = 0;
    virtual DataType peek() const = 0;

    virtual bool isEmpty() const = 0;
    virtual bool isFull() const = 0;

    virtual DataType getMinimum() const = 0;

    virtual ~StackInterface() {}
};


