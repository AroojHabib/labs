#include <iostream>
#include "EnhancedStack.h"

using namespace std;

int main()
{
    int size;

    cout << "Enter stack capacity: ";
    cin >> size;

    EnhancedStack<int> stack(size);

    int choice;
    int value;

    do
    {
        cout << "\n------ STACK OPERATIONS ------\n";
        cout << "1. Push element\n";
        cout << "2. Pop element\n";
        cout << "3. Show top element\n";
        cout << "4. Check if stack is empty\n";
        cout << "5. Check if stack is full\n";
        cout << "6. Display stack\n";
        cout << "7. Show minimum element\n";
        cout << "8. Exit\n";

        cout << "Enter option: ";
        cin >> choice;

        switch (choice)
        {
        case 1:
            cout << "Enter value: ";
            cin >> value;
            stack.push(value);
            break;

        case 2:
            cout << "Removed element: " << stack.pop() << endl;
            break;

        case 3:
            cout << "Top element: " << stack.peek() << endl;
            break;

        case 4:
            if (stack.isEmpty())
                cout << "Stack is empty\n";
            else
                cout << "Stack is not empty\n";
            break;

        case 5:
            if (stack.isFull())
                cout << "Stack is full\n";
            else
                cout << "Stack is not full\n";
            break;

        case 6:
            stack.display();
            break;

        case 7:
            cout << "Minimum element: " << stack.getMinimum() << endl;
            break;

        case 8:
            cout << "Program terminated\n";
            break;

        default:
            cout << "Invalid choice\n";
        }

    } while (choice != 8);

    return 0;
}