

#include <iostream>
#include "StackInterface.h"

using namespace std;

template <class DataType>
class EnhancedStack : public StackInterface<DataType>
{
private:

    DataType* stackArray;      
    DataType* minimumArray;    

    int stackTop;
    int minTop;
    int capacity;

public:

    
    EnhancedStack(int size)
    {
        capacity = size;

        stackArray = new DataType[capacity];
        minimumArray = new DataType[capacity];

        stackTop = -1;
        minTop = -1;
    }

    
    void push(DataType item)
    {
        if (isFull())
        {
            cout << "Stack Overflow!\n";
            return;
        }

        stackTop++;
        stackArray[stackTop] = item;

        if (minTop == -1 || item <= minimumArray[minTop])
        {
            minTop++;
            minimumArray[minTop] = item;
        }

        cout << item << " inserted in stack\n";
    }

    
    DataType pop()
    {
        if (isEmpty())
        {
            cout << "Stack Underflow!\n";
            return DataType();
        }

        DataType removed = stackArray[stackTop];
        stackTop--;

        if (removed == minimumArray[minTop])
        {
            minTop--;
        }

        return removed;
    }

    
    DataType peek() const
    {
        if (isEmpty())
        {
            cout << "Stack is empty\n";
            return DataType();
        }

        return stackArray[stackTop];
    }

    
    DataType getMinimum() const
    {
        if (isEmpty())
        {
            cout << "Stack is empty\n";
            return DataType();
        }

        return minimumArray[minTop];
    }

    
    bool isEmpty() const
    {
        return stackTop == -1;
    }

   
    bool isFull() const
    {
        return stackTop == capacity - 1;
    }

   
    void display() const
    {
        if (isEmpty())
        {
            cout << "Stack has no elements\n";
            return;
        }

        cout << "Stack elements (Top ? Bottom)\n";

        for (int i = stackTop; i >= 0; i--)
        {
            cout << stackArray[i] << endl;
        }
    }

  
    ~EnhancedStack()
    {
        delete[] stackArray;
        delete[] minimumArray;
    }
};


