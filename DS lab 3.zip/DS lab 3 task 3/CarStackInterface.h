
#include <string>
using namespace std;

class CarStackInterface
{
public:
    virtual void parkCar(string carNumber) = 0;
    virtual string removeTopCar() = 0;
    virtual bool isEmpty() const = 0;
    virtual bool isFull() const = 0;

    virtual int totalCars() const = 0;
    virtual bool searchCar(string carNumber) const = 0;
    virtual void showCars() const = 0;

    virtual ~CarStackInterface() {}
};

