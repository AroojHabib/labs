#include <iostream>
#include "myCarStack.h"

using namespace std;

int main()
{
    myCarStack parking;

    int choice;
    string carNumber;

    do
    {
        cout << "\n---- Parking Lot System ----\n";
        cout << "1. Park a new car\n";
        cout << "2. Remove a car\n";
        cout << "3. Show parked cars\n";
        cout << "4. Total cars parked\n";
        cout << "5. Search a car\n";
        cout << "6. Exit\n";

        cout << "Enter choice: ";
        cin >> choice;

        switch (choice)
        {

        case 1:
            cout << "Enter car number: ";
            cin >> carNumber;
            parking.parkCar(carNumber);
            break;

        case 2:
            cout << "Enter car number to remove: ";
            cin >> carNumber;
            parking.removeCar(carNumber);
            break;

        case 3:
            parking.showCars();
            break;

        case 4:
            cout << "Total cars parked: " << parking.totalCars() << endl;
            break;

        case 5:
            cout << "Enter car number to search: ";
            cin >> carNumber;

            if (parking.searchCar(carNumber))
                cout << "Car found in parking.\n";
            else
                cout << "Car not present.\n";

            break;

        case 6:
            cout << "System closed.\n";
            break;

        default:
            cout << "Invalid option.\n";
        }

    } while (choice != 6);

    return 0;
}