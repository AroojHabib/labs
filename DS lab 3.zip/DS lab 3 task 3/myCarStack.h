
#include <iostream>
#include "CarStackInterface.h"

using namespace std;

class myCarStack : public CarStackInterface
{
private:
    string carStack[8];     
    int top;

public:

    myCarStack()
    {
        top = -1;
    }

    bool isEmpty() const
    {
        return top == -1;
    }

    bool isFull() const
    {
        return top == 7;
    }

    int totalCars() const
    {
        return top + 1;
    }

    void parkCar(string carNumber)
    {
        if (isFull())
        {
            cout << "Parking lot is full!\n";
            return;
        }

        carStack[++top] = carNumber;
        cout << "Car " << carNumber << " parked.\n";
    }

    string removeTopCar()
    {
        if (isEmpty())
        {
            cout << "Parking lot is empty.\n";
            return "";
        }

        return carStack[top--];
    }

    bool searchCar(string carNumber) const
    {
        for (int i = 0; i <= top; i++)
        {
            if (carStack[i] == carNumber)
                return true;
        }
        return false;
    }

    void showCars() const
    {
        if (isEmpty())
        {
            cout << "No cars parked.\n";
            return;
        }

        cout << "Cars in Parking (Last parked first):\n";

        for (int i = top; i >= 0; i--)
        {
            cout << carStack[i] << endl;
        }
    }

   
    void removeCar(string carNumber)
    {
        if (isEmpty())
        {
            cout << "Parking lot empty.\n";
            return;
        }

        myCarStack tempStack;
        bool found = false;

        while (!isEmpty())
        {
            string current = removeTopCar();

            if (current == carNumber)
            {
                cout << "Car " << carNumber << " removed from parking.\n";
                found = true;
                break;
            }

            tempStack.parkCar(current);
        }

        while (!tempStack.isEmpty())
        {
            parkCar(tempStack.removeTopCar());
        }

        if (!found)
        {
            cout << "Car not found in parking.\n";
        }
    }
};

