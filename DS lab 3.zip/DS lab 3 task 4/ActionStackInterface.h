
#include <string>
using namespace std;


class ActionStackInterface {
public:
    virtual void push(string action) = 0;
    virtual string pop() = 0;
    virtual bool isEmpty() const = 0;
    virtual void display() const = 0;

    virtual ~ActionStackInterface() {}
};


