
#include <iostream>
#include "ActionStackInterface.h"

using namespace std;

class ActionStack : public ActionStackInterface {
private:
    string* stackArr;
    int topIndex;
    int maxSize;

public:
    ActionStack(int size = 100) {   
        maxSize = size;
        stackArr = new string[maxSize];
        topIndex = -1;
    }

    void push(string action) {
        if (topIndex >= maxSize - 1) {
            cout << "Action stack overflow!\n";
            return;
        }
        stackArr[++topIndex] = action;
    }

    string pop() {
        if (isEmpty()) {
            return "";
        }
        return stackArr[topIndex--];
    }

    bool isEmpty() const {
        return topIndex == -1;
    }

    void display() const {
        if (isEmpty()) {
            cout << "Stack is empty.\n";
            return;
        }
        cout << "Stack elements (top -> bottom):\n";
        for (int i = topIndex; i >= 0; i--) {
            cout << stackArr[i] << endl;
        }
    }

    ~ActionStack() {
        delete[] stackArr;
    }
};

