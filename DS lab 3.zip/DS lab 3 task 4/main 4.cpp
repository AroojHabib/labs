#include <iostream>
#include "ActionStack.h"

using namespace std;

int main() {
    string text = "";
    ActionStack undoStack;
    ActionStack redoStack;

    int choice;
    char ch;

    do {
        cout << "----- Basic Text Editor -----";
        cout << "Current text: " << text <<endl;
        cout << "1. Type a character";
        cout << "2. Delete last character";
        cout << "3. Undo";
        cout << "4. Redo";
        cout << "5. Exit";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {

        case 1: {
            cout << "Enter character to type: ";
            cin >> ch;
            text += ch;
            undoStack.push("TYPE " + string(1, ch));
            
            while (!redoStack.isEmpty()) redoStack.pop();
            break;
        }

        case 2: {
            if (!text.empty()) {
                char deleted = text.back();
                text.pop_back();
                undoStack.push("DELETE " + string(1, deleted));
                while (!redoStack.isEmpty()) redoStack.pop();
                cout << "Deleted '" << deleted << endl;
            }
            else {
                cout << "Nothing to delete.";
            }
            break;
        }

        case 3: { // Undo
            if (undoStack.isEmpty()) {
                cout << "Nothing to undo. ";
                break;
            }
            string lastAction = undoStack.pop();
            redoStack.push(lastAction);

            if (lastAction.substr(0, 4) == "TYPE") {
                text.pop_back(); 
            }
            else if (lastAction.substr(0, 6) == "DELETE") {
                text += lastAction.back();
            }
            cout << "Undo performed.";
            break;
        }

        case 4: { 
            if (redoStack.isEmpty()) {
                cout << "Nothing to redo.";
                break;
            }
            string redoAction = redoStack.pop();
            undoStack.push(redoAction);

            if (redoAction.substr(0, 4) == "TYPE") {
                text += redoAction.back();
            }
            else if (redoAction.substr(0, 6) == "DELETE") {
                text.pop_back();
            }
            cout << "Redo performed.";
            break;
        }

        case 5:
            cout << "Exiting editor...";
            break;

        default:
            cout << "Invalid choice!";
        }

    } while (choice != 5);

    return 0;
}