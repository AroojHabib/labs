
#include <iostream>
#include "AbstractStack.h"
using namespace std;

template <class T>
class myStack : public AbstractStack<T> {

private:
    T* arr;
    int topIndex;
    int maxSize;

public:

    myStack(int size) {
        maxSize = size;
        arr = new T[maxSize];
        topIndex = -1;
    }

    void push(T value) {
        if (isFull()) {
            cout << "Stack Overflow\n";
        }
        else {
            arr[++topIndex] = value;
        }
    }

    T pop() {
        if (isEmpty()) {
            cout << "Stack Underflow\n";
            return T();
        }
        return arr[topIndex--];
    }

    T top() const {
        if (isEmpty()) {
            cout << "Stack Empty\n";
            return T();
        }
        return arr[topIndex];
    }

    bool isEmpty() const {
        return topIndex == -1;
    }

    bool isFull() const {
        return topIndex == maxSize - 1;
    }

    void display() const {
        for (int i = topIndex; i >= 0; i--) {
            cout << arr[i] << endl;
        }
    }

    ~myStack() {
        delete[] arr;
    }
};


